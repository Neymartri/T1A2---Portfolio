URL to your portfolio web
Link to github repo 
descript. of your porfolio
purpose: 
Functionality: 
sitemap: 
screenshots: 
target audience: 
Tech stack (html, css, deployment platf.): 

Strong tag: indicates bold and important element 

root variables represents the HTML element and is identical to the selector HTML Main-text(gives header text the same color)

Use CSS shadow generator to create back shadow effect 

use grid display to set sections of grid 

Create a dropdown link for Contact using css hover 

using grit template column in section 2 to split the section in 2 column by autofit as many columns in to a the row. column should never be smaller than 320px and max expand is 1fr. 
problem while laying out the blog post it was not up to desire. 

Dark and Light theme was optimised using 2 html pages and 2 different css theme layout 

limitation: with lack of Jscript, wasn't able to have the transition more smoothly - although i was able to figure-out using this alternative also works by anchoring between 2htmls. 